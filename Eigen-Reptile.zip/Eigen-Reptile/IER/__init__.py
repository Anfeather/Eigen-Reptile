"""
IER for supervised meta-learning.
"""
